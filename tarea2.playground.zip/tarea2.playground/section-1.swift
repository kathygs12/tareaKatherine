// Playground - noun: a place where people can play

import UIKit


enum Velocidades : Int {
    case Apagado = 0, velocidadBaja = 2, velocidadMedia = 50, velocidadAlta = 120
    
    init(){
      self = .Apagado
    }
    
    init( velocidadInicial : Velocidades ){
        self=velocidadInicial
    }
}

class Auto{
   var velocidad = Velocidades()
   
    init(){
     velocidad = Velocidades(velocidadInicial: Velocidades())
     velocidad = .Apagado
    }
    
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String){
      var result = (velocidad.rawValue,"")
        
        switch velocidad {
        case .Apagado:
            velocidad = .velocidadBaja
            result.1="Apagado"
        case .velocidadBaja:
            velocidad = .velocidadMedia
            result.1="velocidad Baja"
        case .velocidadMedia:
            velocidad = .velocidadAlta
            result.1="velocidad Media"
        case .velocidadAlta:
            velocidad = .Apagado
             result.1="velocidad Alta"
        }
       return result
    }
}

    var auto=Auto()
    var numeros=0...20


    for num in numeros{
        var result=auto .cambioDeVelocidad()
        print(" \(result.0),\(result.1) ")
    }

